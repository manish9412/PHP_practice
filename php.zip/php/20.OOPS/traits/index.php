<?php

trait code
{	
	public function game()
	{
		echo "<br><br>This is sample function for traits<br><br>";
	}
}
trait code3
{
	public function sample()
	{
		echo "<br><br>This is an example function in class trait code3<br><br>";
	}
}

class codegame
{
	use code,code3;
}

class code2
{
	use code;

}

$obj1 = new code2();
$obj1->game();
$obj2 = new codegame();
$obj2->sample();
$obj2->game();



?>