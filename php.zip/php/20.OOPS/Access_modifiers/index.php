<?php

class access
{
	public $name;
	public $class;
	public $game;

	function get_name($name)
	{
		$this->name=$name;
		echo $this->name;
	}
	protected function get_class($class)
	{
		$this->class = $class;
		echo $this->class;
	}
	private function get_game($game)
	{
		$this->game = $game;
		echo $this->game;
	}
}
$obj1 = new access();
$obj1->get_name("This is a public Class");
$obj1->get_class("One Class");
$obj1->get_game("Game Class");


?>