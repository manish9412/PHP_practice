<?php

class coding
{
	public $one;
	public $second;
	public function input($one,$second)
	{
		$this->one = $one;
		$this->second = $second;
	}

	public function __destruct()
	{
		echo $this->one." ".$this->second;
	}
}
$obj1 = new coding();
$obj1->input("Another","sample");




?>