<?php
interface code
{
	public function game();
}
class code2 implements code
{
	public function game()
	{
		echo "<br>This is sample<br><br>";
	}
}
class code3 implements code
{
	public function game()
	{
		echo "This is sample in code3 class<br><br>";
	}
}
class code4 implements code
{
	public function game()
	{
		echo "This is sample in code4 class";
	}
}

$obj1 = new code2();
$obj2 = new code3();
$obj3 = new code4();
$obj4 = array($obj1,$obj2,$obj3);

foreach ($obj4 as $values) 
{
	$values->game();
}
?>