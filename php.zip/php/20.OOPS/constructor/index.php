<?php

class code
{
	public $fun1;
	public $fun2;
	public function __construct($fun1,$fun2)
	{
		$this->fun1 = $fun1;
		$this->fun2 = $fun2;

	}
	public function get_name()
	{
		echo $this->fun1.$this->fun2;
	}
}

$obj1 = new code("Manish","Verma");
$obj1-> get_name();




?>