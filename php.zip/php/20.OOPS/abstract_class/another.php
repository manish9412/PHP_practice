<?php

abstract class code
{
	abstract public function start($name);
}
class code2 extends code
{
	public function start($name)
	{
		if($name == "Manish")
		{
			$pre = "Mr.";
		}
		elseif ($name == "Deepshi") 
		{
			$pre = "Mrs.";
		}
		else
		{
			$pre="";
		}
		return "{$pre}{$name}";
	}
} 
$obj1 = new code2;
echo $obj1->start("Manish"); 


?>