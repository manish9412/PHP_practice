<?php
abstract class main
{
	public $name;
	public function __construct($name)
	{
		$this->name = $name;
	}
	public function sample()
	{
		echo "This is only for sample ";
	}
	abstract public function again() : string;

}
class sub_class1 extends main
{
	public function again():string
	{
		return "<br><br>This is sub_class1 function just to check the function $this->name";
	}
}
class sub_class2 extends main
{
	public function again():string
	{
		return "<br><br>This is sub_class2 function just to check the function of abstract $this->name";
	}
}

$obj1 = new sub_class1("Sample1");
echo $obj1->sample();
echo $obj1->again();
$obj2 = new sub_class2("Sample2");
echo $obj2->again();

?>