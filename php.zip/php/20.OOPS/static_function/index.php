<?php

class code 
{
	public static function game()
	{
		echo "This is a static function sample";
	}
}

code :: game();



?>