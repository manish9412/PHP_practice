<?php

	function iter(iterable $myiter)
	{
		foreach ($myiter as $value) 
		{
			echo $value;
		}
	}
	$arr = ["a","b","c"];
	iter($arr);



?>