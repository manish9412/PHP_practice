<?php

class sample
{
	public $name;
	public $room;
 	public function set_name($name,$room)
 	{
 		$this->name = $name;
 		$this->room=$room;
 	}
 	public function get_name()
 	{
 		echo $this->name.$this->room."<br><br>";
 	}
}
$obj1 = new sample();
$obj1->set_name(" Manish "," 23 ");
$obj1->get_name();
$obj2 = new sample();
$obj2->set_name("Kartik","1122");
$obj2->get_name();


?>