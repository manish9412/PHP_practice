<?php

class code
{
		const Leaving_message = "Kartik Sharma";
	
}
	echo code::Leaving_message;

class code2
{
	const call="<br><br>This is another example for the constant";
	function message()
	{
		echo self::call;
	}
}
$obj1 = new code2();
$obj1->message();


?>