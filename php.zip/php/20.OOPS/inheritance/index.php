<?php
class code1
{
	public $name;
	public $game;
	function __construct($name,$game)
	{
		$this->name = $name;
		$this->game = $game;
	}
	function sample()
	{
		echo "This is a sample function just to check the function of inheritance ";
	}
}
class code2 extends code1
{
	function sample2()
	{
		echo "<br><br>This is also an example just to check the inheritance functions<br><br>";
	}
	function output()
	{
		echo $this->name." ".$this->game;
	}
}

$obj1 = new code2("Sample","Car");
$obj1->sample();
$obj1->sample2();
$obj1->output();


?>