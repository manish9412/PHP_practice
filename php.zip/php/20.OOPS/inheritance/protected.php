<?php

class code1
{
	public $name;
	public $game;
	function __construct($name,$game)
	{
		$this->name =$name;
		$this->game =$game;
	}

	protected function output()
	{
		echo $this->name." ".$this->game;
	}
}
class code2 extends code1
{
	function sample2()
	{
		echo "<br><br>This is the sample for code 2 class<br><br>";
		$this->output();
	}
}

$obj1 = new code2("Sample","Car");
$obj1->sample2();





?>