<!DOCTYPE html>
<html>
<head>
	<title>PHP Case sensitive</title>
</head>
<body>


	<?php
		echo "This is sample for the php case sensitive...!!! <br>";
		ECHO "This is another example<br>";
		ecHO "This is another example<br>";

		$car = "van";
		echo "this is $car <br>";
		echo "This is". $CAR ."<br>";
		echo "This is". $Car;
	?>

</body>
</html>