<?php
function sum()
{
	$num = 1234;
	$sum = $rem = 0;
	for($i = 0;$i<strlen($num);$i++)
	{
		$rem = $num%10;
		$sum = $sum + $rem;
		$num=$num/10;
	}
	echo $sum;
}
sum();

echo "<br><br>";
function evenodd()
{
	$num=23;
	if($num % 2 === 0)
	{
		echo "Number is even";
	}
	else
	{
		echo "Number is odd";
	}
}
evenodd();

echo "<br><br>";
function prime()
{    
	$num = 79;  

	$count=0;  
	for ( $i=1; $i<=$num; $i++)  
	{  
	if (($num%$i)==0)  
	{  
	$count++;  
	}  
	}  
	if ($count < 3)  
	{  
	echo "  Number is prime ";  
	}  
	else
	{
		echo "Not Prime";
	}
	    
}
prime();

echo "<br><br>";
function table()
{
	$num =4;
	$product = 0;
	for($i=1;$i<=10;$i++)
	{
		$product = $num * $i;
		echo $product."<br>";
	}	
}
table();

echo "<br><br>";
function fact()
{
	$num = 6;
	$fact = 1;
	for($i=1;$i<=$num;$i++)
	{
		$fact = $i * $fact;
	}
	echo $fact;
}
fact();

echo "<br><br>";
function Armstrong()
{
	$num=420;
	$x=$num;
	$rem=0;
	$arms = 0;
	for($i=0;$i<strlen($num);$i++)
	{
		$rem=$x%10;
		$arms = pow($rem,3) + $arms;
		$x=$x/10;
	}
	if ($arms == $num) 
	{
		echo "Number is armstrong";
	}
	else
	{
		echo "Not Armstrong";
	}
}
Armstrong();

echo "<br><br>";
function palin()
{
	$num=12332111;
	$x=$num;
	$rem=0;
	$sum=0;
	for($i=1;$i<=strlen($num);$i++)
	{
		$rem=$x%10;
		$sum =($sum * 10) + $rem;
		$x=$x/10;
	}
	if ($sum == $num) 
	{
		echo "Palindrome Number";
	}
	else
	{
		echo "Not palindrome number";
	}
}
palin();

echo "<br><br>";
function fab()
{
	$start=0;
	$second=1;
	$num = 10;
	$sum = 0;
	echo $start.$second;
	for($i=0;$i<$num;$i++)
	{
		$sum = $second + $start;
		echo $sum;
		$start = $second;
		$second = $sum;

	}
} 
fab();

echo "<br><br>";
function reverse()
{
	$num = 1234;
	$rev = 0;
	while($num > 1)
	{
		$rem = $num%10;
		$rev=($rev*10)+$rem;
		$num=$num/10;
	}
	echo "Reverse is ".$rev;
}
reverse();

echo "<br><br>";
function swap()
{
	$a=12;
	$b=34;
	echo "Before Swaping: a is ".$a." and b is ".$b;
	$c=$a;
	$a=$b;
	$b=$c;
	echo "<br>After Swaping: a is ".$a." and b is ".$b;
}
swap();

echo "<br><br>";
function alpha_traingle()
{
	$x=range('A','Z');
	for($i=5;$i>=1;$i--)
	{
		for($j=0;$j<=$i;$j++)
		{
			echo ' ';
		}
		$j--;
		for ($k=0; $k <=(5 - $j) ; $k++) 
		{ 
			echo $x[$k];
		}
		echo "<br>";
	}
	echo "<br>";

	for($m=1;$m<=5;$m++)
	{
		for($n=1;$n<=$m;$n++)
		{
			echo $m;
		}
		echo "<br>";
	}


}
alpha_traingle();
?>