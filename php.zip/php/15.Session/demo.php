<?php

session_start();

echo "My name is " . $_SESSION['name'];
echo "<br>And I am from ".$_SESSION['address']."<br><br>";
print_r($_SESSION);


?>