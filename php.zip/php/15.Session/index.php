<?php

session_start();
$_SESSION['name'] = "Manish";
$_SESSION['address'] = "UP";
echo "Session Created";

?>