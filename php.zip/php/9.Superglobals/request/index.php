<!DOCTYPE html>
<html>
<head>
	<title>Request Method</title>
</head>
<body>
	<form method="post" action="<?php $_SERVER['PHP_SELF'];?>" >
		<input type="text" name="fname" placeholder="Enter name">
		<input type="submit" name="submit">
	</form>
	<?php
		if($_SERVER["REQUEST_METHOD"] == "POST")
		{
			$name = $_REQUEST['fname'];
			if(empty($name))
			{
				echo "Name is empty";
			}
			else
			{
				echo $name;
			}
		}
	?>

</body>
</html>
