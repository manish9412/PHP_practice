<!DOCTYPE html>
<html>
<head>
	<title>Get Method</title>
</head>
<body>
	<a href="sample.php?subject=Manish&web=Verma">Click here to see get method</a>

</body>
</html>