<?php

echo "My Name is " .$_GET['subject']." and surname is ".$_GET['web'] ;

?>