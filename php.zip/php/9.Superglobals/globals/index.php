<?php
$x= 5;
$y= 6;

function mine()
{
	$GLOBALS['z'] = $GLOBALS['x'] + $GLOBALS['y'];
}
mine();
echo $z;


?>