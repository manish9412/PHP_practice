<?php

$first = array("One"=>"First","Two"=>"New","Three"=>"Game","Four"=>"Last");
$arrlength=count($first);

foreach($first as $x => $values)
{
	echo "$x = $values<br>";
}

?>