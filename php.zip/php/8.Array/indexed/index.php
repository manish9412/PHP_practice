<?php

$first = array("One","Two","three","Four");

foreach($first as $value)
{
	echo "$value<br>";
}
echo "<br>";
$second = array("One","two","Three","Five");
$arrlength = count($second);
for($x=0; $x < $arrlength ; $x++)
{
	echo $second[$x]."<br>";
}
?>