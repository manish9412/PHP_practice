<?php

$multi = array(
				array("One","first","1"),
				array("Two","second","2"),
				array("Three","Third","3"),
				array("Four","Fourth","4"));
	
	for($row = 0; $row < 4; $row++)
	{
		echo "<br><br>Row number is $row<br>";
		for($x=0;$x<3;$x++)
		{
			echo $multi[$row][$x];
		}
	}

?>

