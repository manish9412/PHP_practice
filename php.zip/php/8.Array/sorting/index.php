<?php

$mine = array("Manish","Aakash","Himanshu","Kartik");

sort($mine);

$arlength = count($mine);
for($x=0;$x<$arlength;$x++)
{
	echo "$mine[$x]<br><br>";
}
?>