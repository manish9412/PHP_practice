<?php
function sample($x,$y)
{
	if($y == 0)
	{
		throw new Exception("Divisor is zero");
	}
	return $x / $y;
}

try
{
	echo sample(5,0);
}
catch(Exception $e)
{
	echo "Unable to process...";
}
finally
{
	echo "Process Complete...";
}
?>