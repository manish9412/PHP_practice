<?php
	
	$x =5;
	$y=4;
	if ($x > $y) 
	{
		echo "Done";
	}
	else
	{
		echo "sorry";
	}

?>