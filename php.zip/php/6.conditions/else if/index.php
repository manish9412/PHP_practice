<?php
	
	$x =4;
	$y=4;
	if ($x > $y) 
	{
		echo "Done";
	}
	else if($x == $y)
	{
		echo "This is correct";
	}
	else
	{
		echo "sorry";
	}

?>