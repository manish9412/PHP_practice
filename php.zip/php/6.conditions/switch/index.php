<?php

$x = 4;
switch($x)
{
	case 1:
		echo "Find out";
		break;
	case 2:
		echo "Find Out at 2";
		break;
	case 3:
		echo "Find out at 3";
		break;
	case 4:
		echo "Find Out at 4";
		break;
}



?>