<?php
	
	class sample
	{
		function name()
		{
			define("Name","This is manish this side");
			echo Name;
		}
	}
$me = new sample();
$me->name();



define("Game", "<br>This is another example");
echo Game;
?>