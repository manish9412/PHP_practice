<?php
	
	echo "Today is " . date("d.M.Y");
	echo "<br>Today is " . date("d/M/Y");
	echo "<br>Today is " . date("d-M-Y");
	echo "<br>Today is " . date("d M Y");

	echo "<br> Time is " .date("h:i:sa");
	

?>