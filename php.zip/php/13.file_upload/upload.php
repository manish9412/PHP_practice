<?php
$target_dir = "uploads/";
$target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
$upload = 1;
$imageType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));

if (isset($_POST['submit'])) 
{	
	$check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
	if($check !== false)
	{
	echo "File is image - " . $check["mime"];
	$upload = 1;
	}
	else
	{
		echo "Not an image";
		$upload = 0;
	}
}



?>

