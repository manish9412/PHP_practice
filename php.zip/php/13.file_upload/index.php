<!DOCTYPE html>
<html>
<head>
	<title>File Upload in php</title>
</head>
<body>

	<form action="upload.php" method="post" enctype="multipart/form-data">
		<input type="file" name="fileToUpload" id="fileToUpload">
		<input type="submit" name="submit">
	</form>

</body>
</html>