<?php

class men
{
	public $x;
	public $y;

	public function __construct($x,$y)
	{
		$this->x = $x;
		$this->y = $y;
	}
	public function call()
	{
		echo "<br>This is  ".$this->x." ". "and"." ".$this->y;
	}
}

$me = new men("Manish" , "22");
echo $me->call();
$mine = new men("kartik","24");
echo $mine->call();
?>