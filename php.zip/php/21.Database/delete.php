<?php

include "connection.php";

$sql = "DELETE FROM sample WHERE Name = 'Mansi'";

$run = mysqli_query($conn,$sql);
if ($run == TRUE) 
{
	echo "Deleted Successfully";
}
else
{
	echo "Sorry Something is wrong";
}



?>