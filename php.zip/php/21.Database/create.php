<?php

include "connection.php";

$sql = "CREATE DATABASE manish_db";
$run = mysqli_query($conn,$sql);
if (isset($run)) 
{
	echo "Created Database";
}
else
{
	echo "Not created Database";
}


?>