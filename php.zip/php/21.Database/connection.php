<?php

$servername="localhost";
$username = "root";
$password = "";
$dbname = "manish_db";
$conn = new mysqli($servername,$username,$password,$dbname);

if ($conn) 
{
	#echo " Connected";
}
else
{
	echo "Not Connected";
}


?>