<?php

include "connection.php";

$sql = "SELECT Name , Email FROM sample";

$run = mysqli_query($conn,$sql);
if ($run->num_rows > 0) 
{
	while ($row = $run->fetch_assoc()) 
	{
		echo "Name is: ".$row['Name']." Email is: ".$row['Email']."<br><br>";
	}
}
else
{
	echo "Sorry Something is wrong";
}



?>