<?php

include "connection.php";

$sql = "CREATE TABLE sample(Name varchar(100) , Email varchar(100) )";
$run = mysqli_query($conn,$sql);
if (isset($run)) 
{
	echo "Table Created";
}
else
{
	echo "Not Created Table";
}


?>