<?php

include "connection.php";

$sql="INSERT INTO sample(Name,Email) VALUES('Kartik','kk@gmail.com');";
$sql .="INSERT INTO sample(Name,Email) VALUES('Manu','mm@gmail.com');";
$sql .="INSERT INTO sample(Name,Email) VALUES('Aakash','mm@gmail.com')";

if ($conn->multi_query($sql) === TRUE) 
{
	echo "Inserted";
}
else
{
	echo "Error";
}

?>