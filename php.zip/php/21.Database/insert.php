<?php

include "connection.php";

$sql = "INSERT INTO sample(Name,Email) VALUES('Manish','manish@gmail.com')";
$run = mysqli_query($conn,$sql);
if($conn->query($sql) === TRUE)
{
	echo "Data Inserted successfully";
}
else
{
	echo "Not inserted data ";
}



?>