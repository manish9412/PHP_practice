<?php

// include "connection.php";
// $sql =$conn->prepare( "INSERT INTO sample(Name,Email) VALUES(?,?)");
// 		$sql->bind_param("sss",$Name,$Email);

// 		$Name = "Himashu";
// 		$Email="h@gmail.com";

// 		$Name="Nitin";
// 		$Email="n@gmail.com";

// 		echo "New Records Added";

// 		$sql->close();
// 		$conn->close();
?>