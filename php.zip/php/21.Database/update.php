<?php

include "connection.php";

$sql = "UPDATE sample SET Name = 'Nitin' WHERE Name = 'Aakash' ";

$run = mysqli_query($conn,$sql);
if ($run == TRUE) 
{
	echo "Updated Successfully";
}
else
{
	echo "Sorry Something is wrong";
}



?>