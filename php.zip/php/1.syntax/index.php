<!DOCTYPE html>
<html>
<head>
	<title>PHP Syntax</title>
</head>
<body>


	<?php
		echo "This is sample for the php syntax...!!!";
	?>

</body>
</html>