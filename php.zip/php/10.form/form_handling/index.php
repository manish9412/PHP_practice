<!DOCTYPE html>
<html>
<head>
	<title>Form Handling</title>
</head>
<body>
	<form action="result.php" method="post">
		<label>Enter Name: </label>
		<input type="text" name="fname" placeholder="Enter Name">
		<br><br>
		<label>Enter Password: </label>
		<input type="password" name="fpass" placeholder="Enter Password">
		<br><br>
		<input type="submit" name="submit">
	</form>

</body>
</html>