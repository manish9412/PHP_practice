<?php

$name = $_POST['fname'];
$pass = $_POST['fpass'];

if (empty($name) && empty($pass)) 
{
	echo "sorry...!! Fill data First";
}
else
{
	echo "Welcome ".$name. "<br>Your Password is ".$pass;
}
?>