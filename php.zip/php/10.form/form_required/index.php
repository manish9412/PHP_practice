<!DOCTYPE html>
<html>
<head>
	<title>Required in Form </title>
	<style>
		.error{
			color: red;
		}
	</style>
</head>
<body>
	<?php

	$name = $email = $web = $comment = $gender = ""; 
	$name_err = $email_err = $web_err = $comment_err = $gender_err = "";

	if ($_SERVER['REQUEST_METHOD'] == "POST") 
	{
		if(empty($_POST['name']))
		{
			$name_err = "Required";
		}
		else
		{
			$name = $_POST['name'];
		}
		if(empty($_POST['email']))
		{
			$email_err = "Required";
		}
		else
		{
			$email = $_POST['email'];
		}
		if(empty($_POST['website']))
		{
			$web_err = "Required";
		}
		else
		{
			$web =  $_POST['website'];
		}
		if(empty($_POST['comment']))
		{
			$comment_err = "Required";
		}
		else
		{
			$comment =  $_POST['comment'];
		}
		if(empty($_POST['gender']))
		{
			$gender_err = "Required";
		}
		else
		{
			$gender =  $_POST['gender'];
		}
	}

	?>

	
	<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">  
  Name: <input type="text" name="name">
  <span class="error">* <?php echo $name_err;?></span>
  <br><br>
  E-mail: <input type="text" name="email">
  <span class="error">* <?php echo $email_err;?></span>
  <br><br>
  Website: <input type="text" name="website">
  <span class="error"><?php echo $web_err;?></span>
  <br><br>
  Comment: <textarea name="comment" rows="5" cols="40"></textarea>
  <br><br>
  Gender:
  <input type="radio" name="gender" value="female">Female
  <input type="radio" name="gender" value="male">Male
  <input type="radio" name="gender" value="other">Other
  <span class="error">* <?php echo $gender_err;?></span>
  <br><br>
  <input type="submit" name="submit" value="Submit">  
</form>

<?php
echo "$name <br>";
echo "$email <br>";
echo "$web <br>";
echo "$comment <br>";
echo "$gender <br>";
?>
</body>
</html>