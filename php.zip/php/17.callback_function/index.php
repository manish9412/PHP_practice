<?php

	$arr = ["one","two","three","four"];
	$output = array_map(function($arr){return  strlen($arr);}, $arr);
	print_r($output);



?>