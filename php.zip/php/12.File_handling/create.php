<?php

$create = fopen("create.txt","w") or die("Sorry");
$data = "Hey this is a sample file created for the ceate file in fileHandling...!!!";
fwrite($create, $data);

$data="Hey";
fwrite($create,$data);

fclose($create);

?>