<?php
$open = fopen("sample.txt","r") or die("Nothing in file to show");
echo fread($open,filesize("sample.txt"));

// for one line only ---> echo fgets($open , filesize("sample.txt"));
fclose($open);
?>