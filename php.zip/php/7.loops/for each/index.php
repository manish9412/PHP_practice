<?php
#foreach loop
$color =array ("game","car","card");

foreach ($color as $values ) 
{
	echo $values."<br>";
}

$names = array("Manish"=>"Employee","Kartik"=>"Employee","Himanshu"=>"Employee");
foreach($names as $x => $val)
{
	echo "$x = $val<br>";
}

?>