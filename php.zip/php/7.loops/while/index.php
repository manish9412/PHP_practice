<?php

$x= 10 ;
while($x>7)
{
	echo "This is while loop<br>";
	$x--;
}



?>
