<?php

for($x=4;$x<10;$x++)
{
	echo $x." This is for loop<br>";
}



?>