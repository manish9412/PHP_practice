<?php

	$x = 5;
	do
	{
		echo "This is do while loop<br>";
		$x++;
	}
	while ($x<8)

?>