<?php
  
  $data = "Manish this side(String validation) ";
  echo filter_var($data,FILTER_SANITIZE_STRING);

  $int = "awefjenfa21e1.weqt";
  if (!filter_var($int,FILTER_VALIDATE_INT) === FALSE) 
  {
  	echo "<br><br>Integer is valid(Integer Validation)";
  }
  else
  {
  	echo "<br><br>Not Valid";
  }

?>