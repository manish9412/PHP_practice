<?php

$x= "Manish";  //Global Variable

function my()
{
	#Not Working inside function ----- echo "This is global variable".$x;

}
my();

echo "<br>This is global Variable  ".$x;


function name()
{
	$y = "Kartik";
	echo "<br>This is local variable ".$y;
}

name();

#Not working outside function---- echo "This is local variable".$y;

//Global keyword
function another()
{
	global $x;
    $x = "Nitin";
	echo "<br><br>This is global variable ".$x;
}

another();
echo "<br>This is new value of x ".$x;


//static variable
function static_fun()
{
	static $m = 9;
	echo "<br>This is static variable ".$m;
	$m++;
}

static_fun();
static_fun();
static_fun();

?>
