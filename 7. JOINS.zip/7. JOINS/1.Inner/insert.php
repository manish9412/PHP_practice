<?php

include "connection.php";

$sql = "INSERT INTO  join2(Name,employee_id,City)VALUES('Manish',1,'Shamli'),('Shubham',178945,'Shamli'),('Kartik',12,'Manali'),('Megha',123,'Mogha'),('Mikky',1234,'Delhi'),('Rahul',1133,'Panipat'),('Manisha',124541,'Rhotak'),('Himanshu',15452,'Bhiwani'),('Manav',17842,'Ludhiana'),('Hemant',14512,'Rhotak'),('Praveen',145331,'Shamli'),('Raghu',14785,'Delhi'),('Suraj',1741351,'Shimla'),('Sandeep',1541245,'Shamli'),('Rohit',1745698,'Himchal'),('Sahil',1743659,'Himachal'),('Nitin',17412,'Ambala')";

$run = mysqli_query($conn,$sql);

if (isset($run)) 
{
	echo "created";
}
else
{
	echo "Sorry";
}

?>