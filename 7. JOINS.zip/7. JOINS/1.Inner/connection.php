<?php

$servername = "localhost";
$username = "root";
$password="";
$dbname ="joins";

$conn = mysqli_connect($servername,$username,$password,$dbname);

if (!$conn) 
{
	echo "error";
}



?>